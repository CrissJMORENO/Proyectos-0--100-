package com.example.imagecaptureapp.util

import android.content.Context
import android.net.Uri
import android.util.Base64
import java.io.File
import java.io.FileInputStream
import java.io.IOException

object ImageUtils {

    @Throws(IOException::class)
    fun convertImageToBase64(context: Context, imageUri: Uri): String {
        val inputStream = context.contentResolver.openInputStream(imageUri)
        val byteArray = inputStream?.readBytes() ?: throw IOException("Error al leer bytes del InputStream.")
        inputStream.close()
        return Base64.encodeToString(byteArray, Base64.DEFAULT)
    }

}
