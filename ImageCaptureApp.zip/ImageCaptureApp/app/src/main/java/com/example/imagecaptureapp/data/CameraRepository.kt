package com.example.imagecaptureapp.data
import com.example.imagecaptureapp.data.model.ApiResponse
import com.example.imagecaptureapp.domain.Photo

interface CameraRepository {
    suspend fun takePhoto(): Photo
    suspend fun savePhotoToServer(photo: Photo): Photo
    suspend fun uploadImage(imageBase64: String): ApiResponse
}
