package com.example.imagecaptureapp.data.model

data class ApiResponse(val status: String, val url: String)