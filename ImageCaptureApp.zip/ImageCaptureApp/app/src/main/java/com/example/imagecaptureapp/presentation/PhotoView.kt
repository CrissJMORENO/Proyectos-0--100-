import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.tooling.preview.Preview
import coil.compose.rememberImagePainter

@Composable
fun PhotoView(url: String) {
    Image(
        painter = rememberImagePainter(data = url),
        contentDescription = null,  // puedes agregar una descripción si es necesario
        modifier = Modifier.fillMaxSize(),
        contentScale = ContentScale.Crop  // ajusta el contenido de la imagen
    )
}
