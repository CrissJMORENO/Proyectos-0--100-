package com.example.imagecaptureapp.domain

data class Post(val id: String, val imageUrl: String)