package com.example.imagecaptureapp.data.remote

import com.example.imagecaptureapp.data.model.ApiResponse
import com.example.imagecaptureapp.domain.Photo
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiService {
    @POST("/path_to_save_photo")
    suspend fun savePhoto(@Body photo: Photo): Response<Photo>

    fun uploadImage(@Body requestBody: Map<String, String>): Call<ApiResponse>

}
