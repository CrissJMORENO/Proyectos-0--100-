package com.example.imagecaptureapp.presentation

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.imagecaptureapp.domain.Photo
import com.example.imagecaptureapp.domain.Post
import com.example.imagecaptureapp.domain.TakePhotoUseCase
import com.example.imagecaptureapp.util.ImageUtils
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.IOException

class MainViewModel(private val context: Context, private val takePhotoUseCase: TakePhotoUseCase) : ViewModel() {
    val photoState: MutableState<Photo?> = mutableStateOf(null)

    fun takePhoto() {
        viewModelScope.launch {
            val photo = takePhotoUseCase.execute()
            photoState.value = photo
        }
    }



    fun convertImageToBase64(context: Context, imageUri: Uri): String {
        val inputStream = context.contentResolver.openInputStream(imageUri)
        val bitmap = BitmapFactory.decodeStream(inputStream)
        val byteArrayOutputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream)
        val byteArray = byteArrayOutputStream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.DEFAULT)
    }

    val messageState = mutableStateOf<String?>(null)
    val posts = MutableLiveData<List<Post>>()

    fun uploadImage(imageUri: Uri) {
        viewModelScope.launch {
            val imageBase64 = try {
                ImageUtils.convertImageToBase64(context, imageUri)
            } catch (e: IOException) {
                messageState.value = "Error al convertir la imagen."
                return@launch
            }

            try {
                val response = takePhotoUseCase.uploadImage(imageBase64)
                if (response.status == "success") {
                    val newPost = Post(response.status, response.url) // Asumiendo que "status" es un identificador único para la imagen
                    val updatedPosts = posts.value?.toMutableList()?.apply { add(newPost) } ?: mutableListOf(newPost)
                    posts.value = updatedPosts
                    messageState.value = "Imagen subida con éxito!"
                } else {
                    messageState.value = "Error al subir la imagen."
                }
            } catch (exception: Exception) {
                messageState.value = "Error al subir la imagen: ${exception.message}"
            }
        }
    }




}
