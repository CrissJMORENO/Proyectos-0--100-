package com.example.imagecaptureapp.domain

import com.example.imagecaptureapp.data.CameraRepository
import com.example.imagecaptureapp.data.model.ApiResponse

class TakePhotoUseCase(private val cameraRepository: CameraRepository) {
    suspend fun execute(): Photo {
        val photo = cameraRepository.takePhoto()
        return cameraRepository.savePhotoToServer(photo)
    }
    suspend fun uploadImage(imageBase64: String): ApiResponse {
        return cameraRepository.uploadImage(imageBase64)
    }
}
