package com.example.imagecaptureapp.data
import com.example.imagecaptureapp.data.model.ApiResponse
import com.example.imagecaptureapp.data.remote.ApiService
import com.example.imagecaptureapp.domain.Photo
import retrofit2.Response

class CameraRemoteDataSourceImpl(private val apiService: ApiService) : CameraRemoteDataSource {
    override suspend fun savePhoto(photo: Photo): Photo {
        val response = apiService.savePhoto(photo)
        if(response.isSuccessful) {
            return response.body()!!
        } else {
            throw Exception("Error al guardar la foto en el servidor")
        }
    }

    override suspend fun uploadImage(imageData: Map<String, String>): ApiResponse {
        // Asegúrate de que la función uploadImage en ApiService devuelva un objeto Call<ApiResponse>
        val call = apiService.uploadImage(imageData)

        // Ejecuta la llamada y almacena la respuesta en una variable
        val response: Response<ApiResponse> = call.execute()

        if (response.isSuccessful && response.body() != null) {
            return response.body()!!
        } else {
            throw Exception("Error al subir la imagen al servidor")
        }
    }
}
