package com.example.imagecaptureapp

import android.content.ContentValues.TAG
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import coil.annotation.ExperimentalCoilApi
import coil.compose.rememberImagePainter
import com.example.imagecaptureapp.data.CameraRemoteDataSourceImpl
import com.example.imagecaptureapp.data.CameraRepositoryImpl
import com.example.imagecaptureapp.data.remote.RetrofitInstance
import com.example.imagecaptureapp.domain.TakePhotoUseCase
import com.example.imagecaptureapp.presentation.MainViewModel
import java.io.File
import android.Manifest
import android.annotation.SuppressLint
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FabPosition
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Scaffold


private const val REQUEST_CAMERA_PERMISSION = 100
class MainActivity : ComponentActivity() {

    private var imageCapture: ImageCapture? = null
    private lateinit var previewView: PreviewView




    private val viewModel by lazy {
        ViewModelProvider(this, object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return MainViewModel(
                    applicationContext, // Pasa el contexto aquí
                    TakePhotoUseCase(
                        CameraRepositoryImpl(
                            CameraRemoteDataSourceImpl(RetrofitInstance.apiService),
                            applicationContext // Añade este contexto aquí
                        )
                    )
                ) as T
            }
        }).get(MainViewModel::class.java)
    }



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.previewView)
        setContent { MainScreen(viewModel, this::captureImage) }
        startCamera()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA_PERMISSION)
        } else {
            setContent { MainScreen(viewModel, this::captureImage) }
            startCamera()
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener(Runnable {
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder()
                .build()
                .also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, imageCapture)
            } catch (exc: Exception) {
                Log.e(TAG, "Error al iniciar la cámara", exc)
                Toast.makeText(this@MainActivity, "Error al iniciar la cámara", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun captureImage() {
        val photoFile = File(externalMediaDirs.first(), "${System.currentTimeMillis()}.jpg")

        val outputFileOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

        imageCapture?.takePicture(outputFileOptions, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                val savedUri = Uri.fromFile(photoFile)
                viewModel.uploadImage(savedUri)
            }

            override fun onError(exception: ImageCaptureException) {
                Log.e(TAG, "Error al guardar la imagen.", exception)
                Toast.makeText(this@MainActivity, "Error al guardar la imagen.", Toast.LENGTH_SHORT).show()
            }
        })
    }
}

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalCoilApi::class, ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel, captureImageAction: () -> Unit) {
    val posts = viewModel.posts.value
    val message = viewModel.messageState.value

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = captureImageAction) {
                Text("Tomar Foto")
            }
        },
        floatingActionButtonPosition = FabPosition.Center
    ) {
        Column {
            if (message != null) {
                Text(text = message)
            }

            LazyColumn {
                items(posts.orEmpty()) { post ->
                    Image(
                        painter = rememberImagePainter(data = post.imageUrl),
                        contentDescription = null
                    )
                }
            }

            // Agrega la vista previa de la cámara aquí
            AndroidView(
                modifier = Modifier.size(300.dp), // Ajusta el tamaño según lo necesites
                factory = { context ->
                    PreviewView(context).apply {
                        // Configura la vista previa de la cámara aquí, si es necesario
                    }
                },
                update = { view ->
                    // Actualiza la vista previa de la cámara aquí, si es necesario
                }
            )
        }
    }
}

