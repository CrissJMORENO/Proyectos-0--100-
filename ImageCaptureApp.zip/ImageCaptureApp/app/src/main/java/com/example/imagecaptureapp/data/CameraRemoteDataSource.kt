package com.example.imagecaptureapp.data
import com.example.imagecaptureapp.data.model.ApiResponse
import com.example.imagecaptureapp.domain.Photo

interface CameraRemoteDataSource {
    suspend fun savePhoto(photo: Photo): Photo
    suspend fun uploadImage(imageData: Map<String, String>): ApiResponse
}
