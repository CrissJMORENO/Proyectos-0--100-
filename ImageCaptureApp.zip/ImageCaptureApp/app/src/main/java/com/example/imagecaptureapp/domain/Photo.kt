package com.example.imagecaptureapp.domain

data class Photo(val id: String, val url: String)