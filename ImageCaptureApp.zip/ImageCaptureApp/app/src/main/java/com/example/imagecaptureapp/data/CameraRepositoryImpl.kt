package com.example.imagecaptureapp.data
import android.content.Context
import android.icu.text.SimpleDateFormat
import android.net.Uri
import android.os.Environment
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.example.imagecaptureapp.data.model.ApiResponse
import com.example.imagecaptureapp.data.remote.RetrofitInstance
import com.example.imagecaptureapp.domain.Photo
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine
import java.util.Locale


class CameraRepositoryImpl(
    private val remoteDataSource: CameraRemoteDataSource,
    private val context: Context
) : CameraRepository {
    private val apiService = RetrofitInstance.apiService

    private val outputDirectory: File
        get() = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: context.filesDir

    companion object {
        private const val FILENAME_FORMAT = "yyyy-MM-dd-HH-mm-ss-SSS"
    }

    override suspend fun takePhoto(): Photo = suspendCoroutine { continuation ->
        val photoFile = File(
            outputDirectory,
            SimpleDateFormat(FILENAME_FORMAT, java.util.Locale.US)
                .format(System.currentTimeMillis()) + ".jpg"
        )

        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

        imageCapture?.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    continuation.resume(Photo("id_temporal", Uri.fromFile(photoFile).toString()))
                }
                override fun onError(exc: ImageCaptureException) {
                    continuation.resumeWithException(exc)
                }
            }) ?: continuation.resumeWithException(IllegalStateException("ImageCapture no está inicializado."))
    }

    private val cameraProviderFuture = ProcessCameraProvider.getInstance(context)

    var imageCapture: ImageCapture? = null

    fun startCamera(lifecycleOwner: LifecycleOwner) {
        cameraProviderFuture.addListener({
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder().build()
            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            imageCapture = ImageCapture.Builder().build()

            cameraProvider.unbindAll()
            cameraProvider.bindToLifecycle(
                lifecycleOwner, cameraSelector, preview, imageCapture
            )
        }, ContextCompat.getMainExecutor(context))
    }

    override suspend fun savePhotoToServer(photo: Photo): Photo {
        return remoteDataSource.savePhoto(photo)
    }

    override suspend fun uploadImage(imageBase64: String): ApiResponse {
        return remoteDataSource.uploadImage(mapOf("image" to imageBase64))
    }
}
