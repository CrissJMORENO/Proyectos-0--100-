package com.example.healthccheckapp.presentation.Screens.login

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Scaffold
import androidx.compose.material.Surface

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.healthccheckapp.presentation.Screens.login.components.Login

import com.example.healthccheckapp.presentation.Screens.login.components.LoginBottomBar
import com.example.healthccheckapp.presentation.Screens.login.components.LoginContent
import com.example.healthccheckapp.presentation.ui.theme.HealthcCheckAppTheme


@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter", "UnusedMaterialScaffoldPaddingParameter")
@Composable
fun LoginScreen(navController: NavHostController) {

    Scaffold(
        topBar = {},
        content = {
            LoginContent(navController)
        },
        bottomBar = {
            LoginBottomBar(navController)
        }
    )
    //para manejar el estado de la peticion del login
    Login(navController = navController)

}



