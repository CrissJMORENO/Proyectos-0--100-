package com.example.healthccheckapp.domain.usecase.auth

import com.example.healthccheckapp.domain.model.User
import com.example.healthccheckapp.domain.repository.AuthRepository
import javax.inject.Inject

class Signup @Inject constructor(private val repository: AuthRepository) {

    suspend operator fun invoke (user: User) = repository.signup(user)
}