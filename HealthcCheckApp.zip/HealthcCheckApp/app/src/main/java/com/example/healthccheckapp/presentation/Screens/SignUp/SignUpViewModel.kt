package com.example.healthccheckapp.presentation.Screens.SignUp

import android.util.Patterns
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.healthccheckapp.domain.model.Response
import com.example.healthccheckapp.domain.model.User
import com.example.healthccheckapp.domain.usecase.auth.AuthUseCase
import com.example.healthccheckapp.domain.usecase.users.UsersUseCases
import com.google.firebase.auth.FirebaseUser
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SignUpViewModel @Inject constructor(private val authUseCase: AuthUseCase, private val usersUseCases: UsersUseCases): ViewModel() {

    var state by mutableStateOf(SignupState())
        private set

    // USERNAME
    var isUsernameValid by mutableStateOf(false)
        private set
    var usernameErrMsg by mutableStateOf("")
        private set

    // EMAIL
    var isEmailValid by mutableStateOf(false)
        private set
    var emailErrMsg by mutableStateOf("")
        private set

    // PASSWORD
    var isPasswordValid by mutableStateOf(false)
        private set
    var passwordErrMsg by mutableStateOf("")
        private set

    // CONFIRMAR CONTRASENA
    var isconfirmPassword by mutableStateOf(false)
        private set
    var confirmPasswordErrMsg by mutableStateOf("")
        private set

    var signupResponse by mutableStateOf<Response<FirebaseUser>?>(null)
        private set

    var user = User()

    fun onEmailInput(email: String) {
        state = state.copy(email = email)
    }

    fun onUsernameInput(username: String) {
        state = state.copy(username = username)
    }

    fun onPasswordInput(password: String) {
        state = state.copy(password = password)
    }

    fun onConfirmPasswordInput(confirmPassword: String) {
        state = state.copy(confirmPassword = confirmPassword)
    }

    fun onSignup(){
        user.username = state.username
        user.email = state.email
        user.password = state.password

        signup(user)
    }

    fun createUser() = viewModelScope.launch {
        user.id = authUseCase.getCurrentUser()!!.uid
        usersUseCases.create(user)
    }

    fun signup(user: User)= viewModelScope.launch{
        signupResponse = Response.Loading
        val result = authUseCase.signup(user)
        signupResponse = result
    }

    var isEnabledloginButton = false

    fun enabledLoginButton(){
        isEnabledloginButton = isEmailValid && isPasswordValid && isUsernameValid && isconfirmPassword
    }

    fun validateConfirmPassword(){
        if (state.password == state.confirmPassword){
            isconfirmPassword = true
            confirmPasswordErrMsg =""
        }
        else {
            isconfirmPassword = false
            confirmPasswordErrMsg = "Las contraseñas no coinciden"
        }
        enabledLoginButton()
    }
    fun validateUsername(){
        if (state.username.length >= 5){
            isUsernameValid = true
            usernameErrMsg = ""
        }
        else {
            isUsernameValid = false
            usernameErrMsg = "Al menos 5 caracteres"
        }
        enabledLoginButton()
    }

    fun validateEmail(){
        //verificar que el email valido
        if (Patterns.EMAIL_ADDRESS.matcher(state.email).matches()){
            isEmailValid = true
            emailErrMsg = ""
        }
        else{
            isEmailValid = false
            emailErrMsg = "El email no es válido"
        }
        enabledLoginButton()
    }

    fun validatePassword(){
        if (state.password.length >= 6){
            isPasswordValid = true
            passwordErrMsg = ""
        }
        else{
            isPasswordValid = false
            passwordErrMsg = "Al menos 6 caracteres"
        }
        enabledLoginButton()
    }
}