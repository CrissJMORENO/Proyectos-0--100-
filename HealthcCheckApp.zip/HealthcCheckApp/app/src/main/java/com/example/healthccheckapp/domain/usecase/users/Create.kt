package com.example.healthccheckapp.domain.usecase.users

import com.example.healthccheckapp.domain.model.User
import com.example.healthccheckapp.domain.repository.UsersRepository
import javax.inject.Inject

class Create @Inject constructor(private val repository: UsersRepository) {

    suspend operator fun invoke (user: User) = repository.create(user)
}