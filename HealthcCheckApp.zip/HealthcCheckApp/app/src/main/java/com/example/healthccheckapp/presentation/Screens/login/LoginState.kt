package com.example.healthccheckapp.presentation.Screens.login

data class LoginState(
    val email: String = "",
    val password: String = ""
)
