package com.example.healthccheckapp.domain.model

import com.google.gson.Gson
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

// representa un modelo de usuario
data class User(
    var id: String = "",
    var username: String = "",
    var email: String = "",
    var password: String = "",
    var image: String = ""
) {

    // Convierte el objeto User a formato JSON.
    fun toJson(): String = Gson().toJson(User(
        id,
        username,
        email,
        password,

        // Codifica la URL de la imagen si existe.
        if (image != "") URLEncoder.encode(image, StandardCharsets.UTF_8.toString()) else ""
    ))

    companion object {
        // Convierte una cadena JSON de vuelta a un objeto User.
        fun fromJson(data: String): User = Gson().fromJson(data, User::class.java)
    }

}