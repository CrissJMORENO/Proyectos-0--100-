package com.example.healthccheckapp.presentation.Screens.profile_update

import android.annotation.SuppressLint
import android.util.Log
import androidx.compose.material.Scaffold
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import com.example.healthccheckapp.presentation.Screens.profile_update.components.ProfileUpdate
import com.example.healthccheckapp.presentation.Screens.profile_update.components.ProfileUpdateContent
import com.example.healthccheckapp.presentation.Screens.profile_update.components.SaveImage

import com.example.healthccheckapp.presentation.components.DefaultTopBar

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter", "UnusedMaterialScaffoldPaddingParameter")

@Composable
fun ProfileUpdateScreen(
    navController: NavHostController,
    user: String
) {
    Log.d("ProfileEditScreen", "Usuario: $user")

    Scaffold(
        topBar = {
            DefaultTopBar(
                title = "Editar usuario",
                upAvailable = true,
                navController = navController
            )
        },
        content = {
            ProfileUpdateContent(navController = navController)
        },
        bottomBar = {}
    )
    SaveImage()
    ProfileUpdate()
}