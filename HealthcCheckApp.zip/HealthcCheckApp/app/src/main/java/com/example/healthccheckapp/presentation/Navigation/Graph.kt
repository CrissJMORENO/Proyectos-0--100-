package com.example.healthccheckapp.presentation.Navigation

object Graph {
    // Gráfico principal o raíz de la aplicación.
    const val ROOT = "root_graph"

    // Subgráfico dedicado a las funcionalidades de autenticación.
    const val AUTHENTICATION = "auth_graph"

    // Gráfico para la interfaz principal post-autenticación.
    const val HOME = "home_graph"

    // Gráfico para ver y editar detalles específicos.
    const val DETAILS = "details_graph"
}