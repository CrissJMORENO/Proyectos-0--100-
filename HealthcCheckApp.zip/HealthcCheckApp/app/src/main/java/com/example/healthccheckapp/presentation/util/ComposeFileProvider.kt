package com.example.healthccheckapp.presentation.util

import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.net.Uri
import android.os.FileUtils
import androidx.core.content.FileProvider
import com.example.healthccheckapp.R
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.util.UUID

class ComposeFileProvider: FileProvider(R.xml.file_paths) {

    companion object {
        // Función para crear un archivo temporal en el dispositivo a partir de un Uri
        fun createFileFromUri(context: Context, uri: Uri): File? {
            return try {
                val stream = context.contentResolver.openInputStream(uri)

                // Crea un archivo temporal en el directorio cache del contexto
                val file = File.createTempFile(
                    "${System.currentTimeMillis()}",
                    ".png",
                    context.cacheDir
                )
                    //FileUtils.copyInputStreamToFile(stream, file)
                // Reemplazo para copyInputStreamToFile
                stream?.use { inputStream ->
                    FileOutputStream(file).use { outputStream ->
                        val buffer = ByteArray(4 * 1024) // buffer size
                        var bytesRead: Int
                        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                            outputStream.write(buffer, 0, bytesRead)
                        }
                    }
                }
                return file
            } catch (e: Exception) {
                e.printStackTrace()
                return null
            }
        }

        // Función para obtener un Uri para una imagen
        fun getImageUri(context: Context): Uri {

            // Crea o accede a un directorio llamado "images" en el directorio cache
            val directory = File(context.cacheDir, "images")
            directory.mkdirs()
            val file = File.createTempFile(
                "selected_image_",
                ".jpg",
                directory
            )

            // Obtiene el nombre del paquete de la aplicación y concatena ".fileprovider"
            val authority = context.packageName + ".fileprovider"
            return getUriForFile(
                context,
                authority,
                file
            )
        }

        // Función para obtener la ruta de un archivo a partir de un Bitmap
        fun getPathFromBitmap(context: Context, bitmap: Bitmap): String {
            val wrapper = ContextWrapper(context)
            var file = wrapper.getDir("Images", Context.MODE_PRIVATE)
            file = File(file,"${UUID.randomUUID()}.jpg")
            val stream: OutputStream = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.JPEG,100,stream)
            stream.flush()
            stream.close()
            return file.path
        }

    }

}