package com.example.healthccheckapp.domain.usecase.users

import com.example.healthccheckapp.domain.repository.UsersRepository
import javax.inject.Inject

class GetUserById @Inject constructor(private val repository: UsersRepository) {

    operator fun invoke(id:String)=repository.getUserById(id)

}