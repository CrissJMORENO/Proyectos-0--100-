package com.example.healthccheckapp.core

object Constants {

    // Constante que representa el nombre de la colección "Users" en Firebase Firestore.
    const val USERS = "Users"
    ///onstante que representa el nombre de la colección "Posts" en Firebase Firestore.
    const val POSTS = "Posts"
}