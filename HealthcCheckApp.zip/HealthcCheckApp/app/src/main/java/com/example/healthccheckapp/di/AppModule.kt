package com.example.healthccheckapp.di

import com.example.healthccheckapp.core.Constants.POSTS
import com.example.healthccheckapp.core.Constants.USERS
import com.example.healthccheckapp.data.repository.AuthRepositoryImpl
import com.example.healthccheckapp.data.repository.PostsRepositoryImpl
import com.example.healthccheckapp.data.repository.UsersRepositoryImpl
import com.example.healthccheckapp.domain.repository.AuthRepository
import com.example.healthccheckapp.domain.repository.PostsRepository
import com.example.healthccheckapp.domain.repository.UsersRepository
import com.example.healthccheckapp.domain.usecase.auth.AuthUseCase
import com.example.healthccheckapp.domain.usecase.auth.GetCurrentUser
import com.example.healthccheckapp.domain.usecase.auth.Login
import com.example.healthccheckapp.domain.usecase.auth.Logout
import com.example.healthccheckapp.domain.usecase.auth.Signup
import com.example.healthccheckapp.domain.usecase.posts.CreatePost
import com.example.healthccheckapp.domain.usecase.posts.DeleteLikePost
import com.example.healthccheckapp.domain.usecase.posts.DeletePost
import com.example.healthccheckapp.domain.usecase.posts.GetPosts
import com.example.healthccheckapp.domain.usecase.posts.GetPostsByIdUser
import com.example.healthccheckapp.domain.usecase.posts.LikePost
import com.example.healthccheckapp.domain.usecase.posts.PostsUseCases
import com.example.healthccheckapp.domain.usecase.posts.UpdatePost
import com.example.healthccheckapp.domain.usecase.users.Create
import com.example.healthccheckapp.domain.usecase.users.GetUserById
import com.example.healthccheckapp.domain.usecase.users.SaveImage
import com.example.healthccheckapp.domain.usecase.users.Update
import com.example.healthccheckapp.domain.usecase.users.UsersUseCases
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Named

@InstallIn(SingletonComponent::class)
@Module
object AppModule {

    // Proporcionar instancia de FirebaseFirestore.
    @Provides
    fun provideFirebaseFirestore(): FirebaseFirestore = Firebase.firestore

    // Proporcionar instancia de FirebaseStorage.
    @Provides
    fun provideFirebaseStorage(): FirebaseStorage = FirebaseStorage.getInstance()

    // Referencia para almacenar imágenes de usuarios en FirebaseStorage.
    @Provides
    @Named(USERS)
    fun provideStorageUsersRef(storage: FirebaseStorage): StorageReference = storage.reference.child(USERS)

    // Referencia para la colección de usuarios en Firestore.
    @Provides
    @Named(USERS)
    fun provideUsersRef(db: FirebaseFirestore): CollectionReference = db.collection(USERS)

    // Referencia para almacenar imágenes de posts en FirebaseStorage.
    @Provides
    @Named(POSTS)
    fun provideStoragePostsRef(storage: FirebaseStorage): StorageReference = storage.reference.child(POSTS)

    // Referencia para la colección de posts en Firestore.
    @Provides
    @Named(POSTS)
    fun providePostsRef(db: FirebaseFirestore): CollectionReference = db.collection(POSTS)

    // Proporcionar instancia de FirebaseAuth.
    @Provides
    fun provideFirebaseAuth(): FirebaseAuth = FirebaseAuth.getInstance()

    // Proporcionar implementación del repositorio de autenticación.
    @Provides
    fun provideAuthRepository(impl: AuthRepositoryImpl): AuthRepository = impl

    // Proporcionar implementación del repositorio de usuarios.
    @Provides
    fun provideUsersRepository(impl: UsersRepositoryImpl): UsersRepository = impl

    // Proporcionar implementación del repositorio de posts.
    @Provides
    fun providePostsRepository(impl: PostsRepositoryImpl): PostsRepository = impl

    // Agrupar y proporcionar casos de uso relacionados con la autenticación.
    @Provides
    fun provideAuthUseCases(repository: AuthRepository) = AuthUseCase(
        getCurrentUser = GetCurrentUser(repository),
        login = Login(repository),
        logout = Logout(repository),
        signup = Signup(repository)
    )

    // Agrupar y proporcionar casos de uso relacionados con usuarios.
    @Provides
    fun provideUsersUseCases(repository: UsersRepository) = UsersUseCases(
        create = Create(repository),
        getUserById = GetUserById(repository),
        update = Update(repository),
        saveImage = SaveImage(repository)
    )

    // Agrupar y proporcionar casos de uso relacionados con posts.
    @Provides
    fun providePostsUseCases(repository: PostsRepository) = PostsUseCases(
        create = CreatePost(repository),
        getPosts = GetPosts(repository),
        getPostsByIdUser = GetPostsByIdUser(repository),
        deletePost = DeletePost(repository),
        updatePost = UpdatePost(repository),
        likePost = LikePost(repository),
        deleteLikePost = DeleteLikePost(repository)
    )

}