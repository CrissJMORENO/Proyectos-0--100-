package com.example.healthccheckapp.domain.repository

import com.example.healthccheckapp.domain.model.Response
import com.example.healthccheckapp.domain.model.User
import com.google.firebase.auth.FirebaseUser

// Interfaz que define las operaciones de autenticación.
interface AuthRepository {

   // Propiedad para obtener el usuario actualmente autenticado.
   val currentUser: FirebaseUser?

   // Método para autenticarse usando correo electrónico y contraseña.
   suspend fun login(email: String, password: String): Response<FirebaseUser>

   // Método para registrar un nuevo usuario.
   suspend fun signup(user: User): Response<FirebaseUser>


   fun logout()

}