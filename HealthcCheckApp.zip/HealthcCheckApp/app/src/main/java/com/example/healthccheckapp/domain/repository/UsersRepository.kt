package com.example.healthccheckapp.domain.repository

import com.example.healthccheckapp.domain.model.User
import com.example.healthccheckapp.domain.model.Response
import kotlinx.coroutines.flow.Flow
import java.io.File

interface UsersRepository {

    // Método para crear un nuevo usuario.
    // Devuelve 'true' en una respuesta exitosa si el usuario se crea correctamente, 'false' de lo contrario.
    suspend fun create(user: User): Response<Boolean>

    suspend fun update(user: User): Response<Boolean>
    suspend fun saveImage(file: File): Response<String>
    fun getUserById(id: String): Flow<User>
}