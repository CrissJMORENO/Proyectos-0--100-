package com.example.healthccheckapp.domain.model

sealed class Response<out T>{

    // Representa el estado de carga o proceso pendiente.
    // No contiene datos ya que solo indica que algo está en proceso de carga
    object Loading: Response<Nothing>()

    // Representa el estado de éxito con datos de tipo 'T', generico.
    data class Success<out T>(val data: T): Response<T>()
    data class Failure<out T>(val exception: Exception?): Response<T>()
}
