package com.example.healthccheckapp.presentation.Screens.SignUp

data class SignupState(
    val username: String = "",
    val email: String = "",
    val password: String = "",
    val confirmPassword: String = "",
)
