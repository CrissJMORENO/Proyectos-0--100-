package com.example.healthccheckapp.presentation.screens.update_post

data class UpdatePostState(
    val image: String = "",
    val name: String = "",
    val description: String = "",
    val diastolicPressure: String = "",
    val systolicPressure: String = ""
)