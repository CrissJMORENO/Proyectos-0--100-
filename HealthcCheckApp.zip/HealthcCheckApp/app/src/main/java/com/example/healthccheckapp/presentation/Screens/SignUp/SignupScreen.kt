package com.example.healthccheckapp.presentation.Screens.SignUp


import android.annotation.SuppressLint
import androidx.compose.material.Scaffold
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import com.example.healthccheckapp.presentation.Screens.SignUp.components.SignUp
import com.example.healthccheckapp.presentation.Screens.SignUp.components.SignupContent

import com.example.healthccheckapp.presentation.components.DefaultTopBar

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter", "UnusedMaterialScaffoldPaddingParameter")
@Composable
fun SignUpScreen(navController: NavHostController){
    Scaffold (
        topBar={
               DefaultTopBar(
                   title = "Nuevo Usuario",
                   upAvailable = true,
                   navController = navController
               )
        },
        content={
            SignupContent(navController)
        },
        bottomBar = {}
    )
    SignUp(navController)

}
