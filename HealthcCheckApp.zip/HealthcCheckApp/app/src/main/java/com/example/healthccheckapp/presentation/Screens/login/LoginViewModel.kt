package com.example.healthccheckapp.presentation.Screens.login

import android.util.Patterns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.healthccheckapp.domain.model.Response
import com.example.healthccheckapp.domain.usecase.auth.AuthUseCase
import com.google.firebase.auth.FirebaseUser
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor(private val authUseCase: AuthUseCase):ViewModel() {

    //State form
    var state by mutableStateOf(LoginState())
        private set //declarar que sea privado impisbilita poder cambiar dicha informacion desde el screen

    //Validacion del email
    var isEmailValid by mutableStateOf(false)
        private set
    var emailErrMsg by  mutableStateOf("")
        private set

    var password by  mutableStateOf("")
        private set
    var isPasswordValid by mutableStateOf(false)
        private set
    var passwordErrMsg by mutableStateOf("")
        private set


    //enable button
    var isEnabledloginButton = false

    fun enabledLoginButton(){
        isEnabledloginButton = isEmailValid && isPasswordValid
    }

    //login Response
    var loginReponse by mutableStateOf<Response<FirebaseUser>?>(null)

    val currentUser = authUseCase.getCurrentUser()

    init {
        if (currentUser != null){ //sesion iniciaad
            loginReponse = Response.Success(currentUser)
        }
    }

    //metodos

    fun onEmailInput (email: String){
        state = state.copy(email=email)
    }

    fun onPasswordInput (password: String){
        state = state.copy(password=password)
    }

    fun login() = viewModelScope.launch {

        loginReponse = Response.Loading
        val result = authUseCase.login(state.email, state.password)
        loginReponse = result
    }

    fun validateEmail(){
        //Email valido
        if (Patterns.EMAIL_ADDRESS.matcher(state.email).matches()){
            isEmailValid = true
            emailErrMsg = ""
        }
        else{
            isEmailValid = false
            emailErrMsg = "El email no es válido"
        }
        enabledLoginButton()
    }

    fun validatePassword(){
        if (state.password.length >= 6){
            isPasswordValid = true
            passwordErrMsg = ""
        }
        else{
            isPasswordValid = false
            passwordErrMsg  = "Al menos 6 caracteres"
        }
        enabledLoginButton()
    }


}
