package com.example.healthccheckapp.presentation.ui.theme

import androidx.compose.ui.graphics.Color


val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF04D8C3)
val Red200 = Color(0xFFB0E5FF)
val Red500 = Color(0xFF9ED2FF)
val Red700 = Color(0xFF185D83)
val Darkgray500 = Color(0xFFA4B5BE)
val Darkgray700 = Color(0xFFF0F0F0)
val Darkgray900 = Color(0xFFFFFFFF)
