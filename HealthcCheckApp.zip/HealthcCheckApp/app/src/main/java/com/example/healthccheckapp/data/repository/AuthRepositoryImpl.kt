package com.example.healthccheckapp.data.repository

import com.example.healthccheckapp.domain.model.Response
import com.example.healthccheckapp.domain.model.User
import com.example.healthccheckapp.domain.repository.AuthRepository
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

// Esta es la implementación de nuestro repositorio de autenticación.
// Está implementando la interfaz AuthRepository.
// También, estamos usando inyección de dependencias para obtener una instancia de FirebaseAuth.
class AuthRepositoryImpl @Inject constructor(private val firebaseAuth: FirebaseAuth): AuthRepository {

    // Propiedad que devuelve el usuario actual de Firebase, si está autenticado.
    override val currentUser: FirebaseUser?
        get() = firebaseAuth.currentUser

    // Método para iniciar sesión. Usa corutinas para realizar la operación de forma asíncrona.
    override suspend fun login(email: String, password: String): Response<FirebaseUser> {

        //  try-catch para manejar posibles errores durante el inicio de sesión
        return try{
            // Intentamos iniciar sesión con el email y la contraseña proporcionados.
            val result = firebaseAuth.signInWithEmailAndPassword(email, password).await()

            // Si el inicio de sesión es exitoso, devolvemos un objeto de respuesta exitoso con el usuario.
            Response.Success(result.user!!)
        }
        catch (e:Exception) {
            // Si hay un error, imprimimos el rastreo del error y devolvemos un objeto de respuesta de fallo.
            e.printStackTrace()
            Response.Failure(e)
        }
    }

    // Método para registrarse. Nuevamente, usamos corutinas.
    override suspend fun signup(user: User): Response<FirebaseUser> {
        return try {
            // Intentamos registrar al usuario con el email y la contraseña del objeto User proporcionado.
            val result = firebaseAuth.createUserWithEmailAndPassword(user.email, user.password).await()

            // Si el registro es exitoso, devolvemos un objeto de respuesta exitoso con el usuario.
            Response.Success(result.user!!)
        }
        catch(e: Exception) {
            // Si hay un error, imprimimos el rastreo del error y devolvemos un objeto de respuesta de fallo.
            e.printStackTrace()
            Response.Failure(e)
        }
    }

    // Método simple para cerrar la sesión del usuario en Firebase.
    override fun logout() {
        firebaseAuth.signOut()
    }
}