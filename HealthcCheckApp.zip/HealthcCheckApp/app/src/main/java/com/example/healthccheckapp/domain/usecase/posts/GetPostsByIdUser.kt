package com.example.healthccheckapp.domain.usecase.posts

import com.example.healthccheckapp.domain.repository.PostsRepository

import javax.inject.Inject

class GetPostsByIdUser @Inject constructor(private val repository: PostsRepository) {

    operator fun invoke(idUser: String) = repository.getPostsByUserId(idUser)

}