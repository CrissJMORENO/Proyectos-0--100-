package com.example.healthccheckapp.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.AlertDialog
import androidx.compose.material.Text
import androidx.compose.material.TextButton

import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun DialogCapturePicture(
    status: MutableState<Boolean>,
    takePhoto: () -> Unit,
    pickImage: () -> Unit,
) {
    if (status.value) {
        AlertDialog(
            onDismissRequest = { status.value = false },
            title = {
                Text(
                    text = "Selecciona una opcion",
                    fontSize = 20.sp,
                    color = Color.Black
                )
            },
            text = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 30.dp)
                        .background(Color.White)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        TextButton(
                            modifier = Modifier.width(130.dp),
                            onClick = {
                                status.value = false
                                pickImage()
                            }
                        ) {
                            Text(text = "Galeria")
                        }
                        TextButton(
                            modifier = Modifier.width(130.dp),
                            onClick = {
                                status.value = false
                                takePhoto()
                            }
                        ) {
                            Text(text = "Camera")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { status.value = false }) {
                    Text("Confirmar")
                }
            }
        )

    }
}
