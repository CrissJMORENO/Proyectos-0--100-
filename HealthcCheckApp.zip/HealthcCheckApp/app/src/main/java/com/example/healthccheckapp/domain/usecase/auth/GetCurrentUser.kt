package com.example.healthccheckapp.domain.usecase.auth

import com.example.healthccheckapp.domain.repository.AuthRepository
import javax.inject.Inject

// se encarga de obtener el usuario actualmente autenticado.
class GetCurrentUser @Inject constructor(private val repository: AuthRepository) {

    operator fun invoke() = repository.currentUser
    //Permite que el objeto 'GetCurrentUser' sea invocado como una función.

}