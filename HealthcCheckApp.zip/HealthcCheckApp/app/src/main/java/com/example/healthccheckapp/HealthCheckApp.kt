package com.example.healthccheckapp

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class HealthCheckApp: Application() {

}