package com.example.healthccheckapp.domain.usecase.auth

class AuthUseCase (
    // La clase 'AuthUseCase' encapsula varios casos de uso relacionados con la autenticación.

    val getCurrentUser: GetCurrentUser, // Cada caso de uso representa una operación específica relacionada con la autenticación.
    val login: Login,
    val logout: Logout,
    val signup: Signup
)