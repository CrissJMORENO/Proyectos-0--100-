package com.example.healthccheckapp.domain.usecase.users

data class UsersUseCases( //indica que esta clase está destinada principalmente a almacenar datos
    val create: Create,
    val getUserById: GetUserById,
    val update: Update,
    val saveImage: SaveImage
)
