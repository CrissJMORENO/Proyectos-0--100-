package com.example.healthccheckap.presentation.screens.detail_post

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import com.example.healthccheckapp.domain.model.Post
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel // indicar a Hilt que este es un ViewModel y debe ser proporcionado con inyección de dependencias.
class DetailPostViewModel @Inject constructor(
    private val savedStateHandle: SavedStateHandle
): ViewModel() {

    // Recuperando la data del 'savedStateHandle' usando la clave "post".
    val data = savedStateHandle.get<String>("post")


    // se transdorma la cadena JSON recuperada en una instancia de `Post`.

    val post = Post.fromJson(data!!)

}