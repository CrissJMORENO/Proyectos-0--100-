package com.example.healthccheckapp.domain.usecase.auth

import com.example.healthccheckapp.domain.repository.AuthRepository
import javax.inject.Inject

class Logout @Inject constructor(private val repository: AuthRepository) {

    operator fun invoke() = repository.logout()
}