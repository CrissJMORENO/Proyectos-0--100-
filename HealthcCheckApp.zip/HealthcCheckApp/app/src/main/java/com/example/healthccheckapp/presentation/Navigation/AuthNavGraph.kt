package com.example.healthccheckapp.presentation.Navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import androidx.navigation.navigation
import com.example.healthccheckapp.presentation.Screens.SignUp.SignUpScreen
import com.example.healthccheckapp.presentation.Screens.login.LoginScreen

//navegación para las pantallas de autenticación.
fun NavGraphBuilder.authNavGraph(navController: NavHostController) {
    //  Establece un subgráfico de navegación para las pantallas de autenticación.

    navigation(
        route = Graph.AUTHENTICATION,
        startDestination = AuthScreen.Login.route
    ) {

        composable(route = AuthScreen.Login.route) {
            LoginScreen(navController)
        }

        composable(route = AuthScreen.Signup.route) {
            SignUpScreen(navController)
        }

    }
}

sealed class AuthScreen(val route: String) {

    object Login: AuthScreen("login")
    object Signup: AuthScreen("signup")

}