package com.example.healthccheckapp.presentation.Screens.profile_update

data class ProfileUpdateState(
    val username: String = "",
    var image: String = ""
)