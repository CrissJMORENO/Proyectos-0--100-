package com.example.healthccheckapp.domain.usecase.posts

import com.example.healthccheckapp.domain.model.Post
import com.example.healthccheckapp.domain.repository.PostsRepository

import java.io.File
import javax.inject.Inject

class CreatePost @Inject constructor(private val repository: PostsRepository){

    suspend operator fun invoke(post: Post, file: File) = repository.create(post, file)

}