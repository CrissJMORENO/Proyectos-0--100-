package com.example.healthccheckapp.domain.usecase.posts

import com.example.healthccheckapp.domain.repository.PostsRepository

import javax.inject.Inject

class LikePost @Inject constructor(private val repository: PostsRepository){

    suspend operator fun invoke(idPost: String, idUser: String) = repository.like(idPost, idUser)

}