package com.example.healthccheckapp.presentation.Screens.Profile

import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.healthccheckapp.domain.model.User
import com.example.healthccheckapp.domain.usecase.auth.AuthUseCase
import com.example.healthccheckapp.domain.usecase.users.UsersUseCases
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProfileViewModel @Inject constructor(private val authUseCase: AuthUseCase, private val usersUseCases: UsersUseCases): ViewModel() {

    var userData by mutableStateOf(User())
        private set //se define que la informacion de userdata no podsra ser cambiada. solo desde este clase
    var currentUser = authUseCase.getCurrentUser()

    //se ejecuta primera para llmar al usuario
    init {
        getUsrrById()
    }

    private fun getUsrrById() = viewModelScope.launch {
        usersUseCases.getUserById(currentUser!!.uid).collect(){
            //se le pasa el id sde sesion del usuario de firestore
            userData = it //al usar
        }

    }
    fun logout(){
        authUseCase.logout()
    }


 }